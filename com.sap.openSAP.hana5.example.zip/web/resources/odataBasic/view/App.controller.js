 sap.ui.controller("opensap.odataBasic.view.App",{
	
}); 

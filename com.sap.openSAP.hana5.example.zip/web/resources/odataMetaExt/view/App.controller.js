//To use a javascript controller its name must end with .controller.js
sap.ui.controller("sap.shineNext.odataMetaExt.view.App", {

});
# com.sap.openSAP.hana5.example
openSAP HANA5 Course: Example Completed Implementation
